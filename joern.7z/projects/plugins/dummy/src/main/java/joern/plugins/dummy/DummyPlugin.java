package joern.plugins.dummy;

import joern.api.plugintypes.JoernPlugin;

public class DummyPlugin extends JoernPlugin
{

	 @Override
     public void execute() throws Exception
	 {

	 }

}
