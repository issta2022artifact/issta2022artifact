package ast.php.expressions;

import ast.expressions.UnaryExpression;

public class ExitExpression extends UnaryExpression
{
}
