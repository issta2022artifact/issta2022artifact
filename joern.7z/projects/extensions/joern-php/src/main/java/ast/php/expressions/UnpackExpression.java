package ast.php.expressions;

import ast.expressions.UnaryExpression;

public class UnpackExpression extends UnaryExpression
{
}
