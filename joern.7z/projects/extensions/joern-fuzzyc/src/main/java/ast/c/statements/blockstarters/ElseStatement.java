package ast.c.statements.blockstarters;

import ast.logical.statements.BlockStarterWithStmtAndCnd;

public class ElseStatement extends BlockStarterWithStmtAndCnd
{



}
