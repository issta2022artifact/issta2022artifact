package ast.expressions;

public class AndExpression extends BinaryOperationExpression
{
}
