package ast.expressions;

public class ForInit extends Expression
{
}
