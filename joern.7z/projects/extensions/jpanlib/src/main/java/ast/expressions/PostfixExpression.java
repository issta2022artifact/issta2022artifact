package ast.expressions;

public class PostfixExpression extends Expression
{
}
