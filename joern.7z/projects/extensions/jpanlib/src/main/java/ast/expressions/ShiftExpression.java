package ast.expressions;

public class ShiftExpression extends BinaryOperationExpression
{
}
