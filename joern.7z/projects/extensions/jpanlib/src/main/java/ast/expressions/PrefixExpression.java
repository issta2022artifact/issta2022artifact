package ast.expressions;

public class PrefixExpression extends Expression
{
}
