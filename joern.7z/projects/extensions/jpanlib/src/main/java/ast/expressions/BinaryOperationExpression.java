package ast.expressions;

public class BinaryOperationExpression extends BinaryExpression
{
}
