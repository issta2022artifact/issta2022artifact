package ast.logical.statements;

public class BlockCloser extends Statement
{
}
