package octopus.server.importer.csv.titan;

public class CSVCommands {

	public static final String ADD = "A";
	public static final String ADD_NO_REPLACE = "ANR";

}
